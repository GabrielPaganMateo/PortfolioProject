from django.apps import AppConfig


class ResumeCollectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Resume_Collect'
